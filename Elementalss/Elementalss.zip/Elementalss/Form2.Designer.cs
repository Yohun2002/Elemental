﻿namespace Elementalss
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ax3e0 = new System.Windows.Forms.PictureBox();
            this.ax2e0 = new System.Windows.Forms.PictureBox();
            this.ax2e1 = new System.Windows.Forms.PictureBox();
            this.ax2e2 = new System.Windows.Forms.PictureBox();
            this.ax4e0 = new System.Windows.Forms.PictureBox();
            this.ax6e0 = new System.Windows.Forms.PictureBox();
            this.ax5e1 = new System.Windows.Forms.PictureBox();
            this.ax5e0 = new System.Windows.Forms.PictureBox();
            this.ax3e1 = new System.Windows.Forms.PictureBox();
            this.ax4e2 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ax4e1 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ax3e2 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.ax2e3 = new System.Windows.Forms.PictureBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.ax3e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax4e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax6e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax5e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax5e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax3e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax4e2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax4e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax3e2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e3)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // ax3e0
            // 
            this.ax3e0.BackgroundImage = global::Elementalss.Properties.Resources.AX3E0;
            this.ax3e0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax3e0.Location = new System.Drawing.Point(60, 120);
            this.ax3e0.Name = "ax3e0";
            this.ax3e0.Size = new System.Drawing.Size(127, 95);
            this.ax3e0.TabIndex = 11;
            this.ax3e0.TabStop = false;
            // 
            // ax2e0
            // 
            this.ax2e0.BackgroundImage = global::Elementalss.Properties.Resources.AX2E0;
            this.ax2e0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax2e0.Location = new System.Drawing.Point(60, 120);
            this.ax2e0.Name = "ax2e0";
            this.ax2e0.Size = new System.Drawing.Size(127, 95);
            this.ax2e0.TabIndex = 10;
            this.ax2e0.TabStop = false;
            // 
            // ax2e1
            // 
            this.ax2e1.BackColor = System.Drawing.SystemColors.Control;
            this.ax2e1.BackgroundImage = global::Elementalss.Properties.Resources.AX2E1;
            this.ax2e1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax2e1.Location = new System.Drawing.Point(60, 120);
            this.ax2e1.Name = "ax2e1";
            this.ax2e1.Size = new System.Drawing.Size(127, 95);
            this.ax2e1.TabIndex = 12;
            this.ax2e1.TabStop = false;
            // 
            // ax2e2
            // 
            this.ax2e2.BackgroundImage = global::Elementalss.Properties.Resources.AX2E2;
            this.ax2e2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax2e2.Location = new System.Drawing.Point(60, 120);
            this.ax2e2.Name = "ax2e2";
            this.ax2e2.Size = new System.Drawing.Size(127, 95);
            this.ax2e2.TabIndex = 15;
            this.ax2e2.TabStop = false;
            // 
            // ax4e0
            // 
            this.ax4e0.BackgroundImage = global::Elementalss.Properties.Resources.AX4E0;
            this.ax4e0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax4e0.Location = new System.Drawing.Point(60, 120);
            this.ax4e0.Name = "ax4e0";
            this.ax4e0.Size = new System.Drawing.Size(127, 95);
            this.ax4e0.TabIndex = 13;
            this.ax4e0.TabStop = false;
            // 
            // ax6e0
            // 
            this.ax6e0.BackgroundImage = global::Elementalss.Properties.Resources.AX6E0;
            this.ax6e0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax6e0.Location = new System.Drawing.Point(60, 120);
            this.ax6e0.Name = "ax6e0";
            this.ax6e0.Size = new System.Drawing.Size(127, 95);
            this.ax6e0.TabIndex = 19;
            this.ax6e0.TabStop = false;
            // 
            // ax5e1
            // 
            this.ax5e1.BackgroundImage = global::Elementalss.Properties.Resources.AX5E1;
            this.ax5e1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax5e1.Location = new System.Drawing.Point(60, 120);
            this.ax5e1.Name = "ax5e1";
            this.ax5e1.Size = new System.Drawing.Size(127, 95);
            this.ax5e1.TabIndex = 20;
            this.ax5e1.TabStop = false;
            // 
            // ax5e0
            // 
            this.ax5e0.BackgroundImage = global::Elementalss.Properties.Resources.AX5E01;
            this.ax5e0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax5e0.Location = new System.Drawing.Point(60, 120);
            this.ax5e0.Name = "ax5e0";
            this.ax5e0.Size = new System.Drawing.Size(127, 102);
            this.ax5e0.TabIndex = 22;
            this.ax5e0.TabStop = false;
            // 
            // ax3e1
            // 
            this.ax3e1.BackgroundImage = global::Elementalss.Properties.Resources.AX3E1;
            this.ax3e1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax3e1.Location = new System.Drawing.Point(60, 120);
            this.ax3e1.Name = "ax3e1";
            this.ax3e1.Size = new System.Drawing.Size(127, 95);
            this.ax3e1.TabIndex = 14;
            this.ax3e1.TabStop = false;
            // 
            // ax4e2
            // 
            this.ax4e2.BackgroundImage = global::Elementalss.Properties.Resources.AX4E21;
            this.ax4e2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax4e2.Image = global::Elementalss.Properties.Resources.vippng_com_balls_png_3716636;
            this.ax4e2.Location = new System.Drawing.Point(60, 120);
            this.ax4e2.Name = "ax4e2";
            this.ax4e2.Size = new System.Drawing.Size(127, 95);
            this.ax4e2.TabIndex = 21;
            this.ax4e2.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(127, 82);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 24);
            this.label18.TabIndex = 10;
            this.label18.Text = "E";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1096, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox1.Location = new System.Drawing.Point(87, 120);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(75, 20);
            this.textBox1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.textBox21);
            this.panel2.Controls.Add(this.textBox22);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(304, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(247, 282);
            this.panel2.TabIndex = 14;
            this.panel2.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(174, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "2";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox2.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox2.Location = new System.Drawing.Point(149, 84);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(74, 50);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(75, 186);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(108, 36);
            this.button2.TabIndex = 4;
            this.button2.Text = "แสดงสูตรโครงสร้าง";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(13, 134);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 20);
            this.textBox21.TabIndex = 2;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(135, 134);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 20);
            this.textBox22.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox1.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox1.Location = new System.Drawing.Point(25, 84);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 50);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // ax4e1
            // 
            this.ax4e1.BackgroundImage = global::Elementalss.Properties.Resources.AX4E1;
            this.ax4e1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax4e1.Location = new System.Drawing.Point(60, 120);
            this.ax4e1.Name = "ax4e1";
            this.ax4e1.Size = new System.Drawing.Size(127, 95);
            this.ax4e1.TabIndex = 16;
            this.ax4e1.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(75, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 24);
            this.label15.TabIndex = 9;
            this.label15.Text = "AX";
            // 
            // ax3e2
            // 
            this.ax3e2.BackgroundImage = global::Elementalss.Properties.Resources.AX3E2;
            this.ax3e2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax3e2.Location = new System.Drawing.Point(60, 120);
            this.ax3e2.Name = "ax3e2";
            this.ax3e2.Size = new System.Drawing.Size(127, 95);
            this.ax3e2.TabIndex = 17;
            this.ax3e2.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox12.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox12.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox12.Location = new System.Drawing.Point(25, 86);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(74, 50);
            this.pictureBox12.TabIndex = 22;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox10.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox10.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox10.Location = new System.Drawing.Point(25, 13);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(74, 50);
            this.pictureBox10.TabIndex = 20;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox11.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox11.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox11.Location = new System.Drawing.Point(149, 13);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(74, 50);
            this.pictureBox11.TabIndex = 21;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox13.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox13.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox13.Location = new System.Drawing.Point(149, 82);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(74, 50);
            this.pictureBox13.TabIndex = 23;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox14.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox14.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox14.Location = new System.Drawing.Point(90, 158);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(74, 50);
            this.pictureBox14.TabIndex = 24;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox8.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox8.Location = new System.Drawing.Point(27, 82);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(74, 50);
            this.pictureBox8.TabIndex = 17;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox9.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox9.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox9.Location = new System.Drawing.Point(148, 86);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(74, 50);
            this.pictureBox9.TabIndex = 18;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox7.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox7.Location = new System.Drawing.Point(148, 13);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(74, 50);
            this.pictureBox7.TabIndex = 16;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox6.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox6.Location = new System.Drawing.Point(27, 13);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(74, 50);
            this.pictureBox6.TabIndex = 15;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox3.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox3.Location = new System.Drawing.Point(30, 37);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(74, 50);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox4.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox4.Location = new System.Drawing.Point(145, 37);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(74, 50);
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox5.BackgroundImage = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Image = global::Elementalss.Properties.Resources.arm_symbol;
            this.pictureBox5.Location = new System.Drawing.Point(95, 104);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(74, 50);
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BackgroundImage = global::Elementalss.Properties.Resources.kisspng_science_5b0e343d5f0de5_0609268615276575333894;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(29, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(247, 257);
            this.panel1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(9, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Central Atom";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(61, 176);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 46);
            this.button1.TabIndex = 0;
            this.button1.Text = "กรอกอะตอมรอบนอก";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ax2e3
            // 
            this.ax2e3.BackgroundImage = global::Elementalss.Properties.Resources.AX2E3;
            this.ax2e3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ax2e3.Location = new System.Drawing.Point(60, 120);
            this.ax2e3.Name = "ax2e3";
            this.ax2e3.Size = new System.Drawing.Size(127, 95);
            this.ax2e3.TabIndex = 18;
            this.ax2e3.TabStop = false;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(135, 60);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 20);
            this.textBox42.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(113, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(170, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "2";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(75, 207);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 36);
            this.button4.TabIndex = 5;
            this.button4.Text = "แสดงสูตรโครงสร้าง";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(15, 132);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 20);
            this.textBox43.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(53, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(76, 186);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 36);
            this.button3.TabIndex = 5;
            this.button3.Text = "แสดงสูตรโครงสร้าง";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(80, 151);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 20);
            this.textBox33.TabIndex = 4;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(16, 83);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 20);
            this.textBox31.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(51, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(173, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 25);
            this.label9.TabIndex = 12;
            this.label9.Text = "2";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(135, 132);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 20);
            this.textBox44.TabIndex = 6;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(132, 84);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 20);
            this.textBox32.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.textBox44);
            this.panel4.Controls.Add(this.button4);
            this.panel4.Controls.Add(this.textBox43);
            this.panel4.Controls.Add(this.textBox41);
            this.panel4.Controls.Add(this.textBox42);
            this.panel4.Controls.Add(this.pictureBox8);
            this.panel4.Controls.Add(this.pictureBox9);
            this.panel4.Controls.Add(this.pictureBox7);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Location = new System.Drawing.Point(27, 342);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(247, 282);
            this.panel4.TabIndex = 16;
            this.panel4.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(173, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 25);
            this.label11.TabIndex = 14;
            this.label11.Text = "4";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(15, 60);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 20);
            this.textBox41.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(51, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 25);
            this.label8.TabIndex = 11;
            this.label8.Text = "1";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.textBox33);
            this.panel3.Controls.Add(this.textBox31);
            this.panel3.Controls.Add(this.textBox32);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.pictureBox5);
            this.panel3.Location = new System.Drawing.Point(582, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(247, 282);
            this.panel3.TabIndex = 15;
            this.panel3.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(142, 90);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(28, 18);
            this.label19.TabIndex = 13;
            this.label19.Text = "CV";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(174, 86);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 25);
            this.label17.TabIndex = 26;
            this.label17.Text = "4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(113, 158);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 25);
            this.label16.TabIndex = 25;
            this.label16.Text = "5";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(49, 86);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 25);
            this.label14.TabIndex = 18;
            this.label14.Text = "3";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(174, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 25);
            this.label13.TabIndex = 17;
            this.label13.Text = "2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(49, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 25);
            this.label12.TabIndex = 16;
            this.label12.Text = "1";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(75, 207);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 20);
            this.textBox55.TabIndex = 7;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(135, 132);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 20);
            this.textBox54.TabIndex = 6;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(71, 233);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(108, 36);
            this.button5.TabIndex = 5;
            this.button5.Text = "แสดงสูตรโครงสร้าง";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(71, 228);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(109, 45);
            this.button6.TabIndex = 14;
            this.button6.Text = "กลับไปยังหน้าแรก";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.ax3e0);
            this.panel7.Controls.Add(this.ax2e0);
            this.panel7.Controls.Add(this.ax2e1);
            this.panel7.Controls.Add(this.ax2e2);
            this.panel7.Controls.Add(this.ax4e0);
            this.panel7.Controls.Add(this.button6);
            this.panel7.Controls.Add(this.ax6e0);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.ax5e1);
            this.panel7.Controls.Add(this.label20);
            this.panel7.Controls.Add(this.ax5e0);
            this.panel7.Controls.Add(this.ax3e1);
            this.panel7.Controls.Add(this.ax4e2);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.ax4e1);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Controls.Add(this.ax3e2);
            this.panel7.Controls.Add(this.ax2e3);
            this.panel7.Location = new System.Drawing.Point(847, 35);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(247, 282);
            this.panel7.TabIndex = 18;
            this.panel7.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(105, 90);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 18);
            this.label20.TabIndex = 12;
            this.label20.Text = "CV";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(13, 132);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 20);
            this.textBox53.TabIndex = 4;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(13, 60);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 20);
            this.textBox51.TabIndex = 2;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(135, 60);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 20);
            this.textBox52.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.textBox55);
            this.panel5.Controls.Add(this.textBox54);
            this.panel5.Controls.Add(this.button5);
            this.panel5.Controls.Add(this.textBox53);
            this.panel5.Controls.Add(this.textBox51);
            this.panel5.Controls.Add(this.textBox52);
            this.panel5.Controls.Add(this.pictureBox12);
            this.panel5.Controls.Add(this.pictureBox10);
            this.panel5.Controls.Add(this.pictureBox11);
            this.panel5.Controls.Add(this.pictureBox13);
            this.panel5.Controls.Add(this.pictureBox14);
            this.panel5.Location = new System.Drawing.Point(304, 342);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(247, 282);
            this.panel5.TabIndex = 17;
            this.panel5.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1096, 680);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ax3e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax4e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax6e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax5e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax5e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax3e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax4e2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax4e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ax3e2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ax2e3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ax3e0;
        private System.Windows.Forms.PictureBox ax2e0;
        private System.Windows.Forms.PictureBox ax2e1;
        private System.Windows.Forms.PictureBox ax2e2;
        private System.Windows.Forms.PictureBox ax4e0;
        private System.Windows.Forms.PictureBox ax6e0;
        private System.Windows.Forms.PictureBox ax5e1;
        private System.Windows.Forms.PictureBox ax5e0;
        private System.Windows.Forms.PictureBox ax3e1;
        private System.Windows.Forms.PictureBox ax4e2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox ax4e1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox ax3e2;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox ax2e3;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Panel panel5;
    }
}